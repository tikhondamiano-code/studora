# Studora MVP Mockups — entire project

This project’s pages, files, and uploads as this browser tab had them at export.
Anything left out is listed below.

## Contents

- `AddFinals.dc.html`
- `Availability.dc.html`
- `DataCalendar.dc.html`
- `IfThen.dc.html`
- `Main.dc.html`
- `PlanPreview.dc.html`
- `Recovery.dc.html`
- `Session.dc.html`
- `SessionDone.dc.html`
- `Today.dc.html`
- `canvas.json` — the canvas: its pages, where each artboard sits, its notes and shapes
- `_runtime/` — what runs the pages in a browser; not part of the design

## Viewing

To view a page, start a local web server in this folder (for example `python3 -m http.server`), then open an artboard’s `.dc.html` file through it. Opening the file directly may not work, because some browsers block its scripts.

## Left out of this export

The export never includes hidden files (files whose names start with a dot) or
files the editor keeps for its own use.
